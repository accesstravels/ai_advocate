#!/bin/bash
# Azure Web App startup script for Python FastAPI

# Set working directory
cd /tmp/*/

# Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# Start the application with gunicorn for better performance
python -m gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --bind 0.0.0.0:8000 --timeout 600
