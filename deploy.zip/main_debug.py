"""
Minimal FastAPI application for Azure App Service debugging
"""
import os
import sys
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(title="Azure AI Avatar Debug Service")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Azure AI Avatar Debug Service is running!"}

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "Azure AI Avatar Debug Service"}

@app.get("/debug")
async def debug():
    return {
        "python_version": sys.version,
        "python_path": sys.path,
        "working_directory": os.getcwd(),
        "environment_variables": dict(os.environ),
        "installed_packages": "Check logs for pip list output"
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    logger.info(f"Starting debug service on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
