#!/bin/bash
# Simple startup script for debugging

# Change to app directory
cd /tmp/*/

# Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# Start with uvicorn directly for debugging
python -m uvicorn main:app --host 0.0.0.0 --port 8000
